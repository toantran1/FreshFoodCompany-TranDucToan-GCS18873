-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2021 at 08:55 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website_mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminEmail` varchar(150) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminPass` varchar(255) NOT NULL,
  `level` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminEmail`, `adminUser`, `adminPass`, `level`) VALUES
(1, 'toan', 'toan@gmail.com', 'toanadmin', 'e10adc3949ba59abbe56e057f20f883e', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bill`
--

CREATE TABLE `tbl_bill` (
  `bill_id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customerName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `code_bill` mediumtext NOT NULL,
  `address_delivery` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `payments` varchar(255) NOT NULL,
  `date_order` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_bill`
--

INSERT INTO `tbl_bill` (`bill_id`, `customerId`, `customerName`, `email`, `code_bill`, `address_delivery`, `status`, `payments`, `date_order`) VALUES
(109, 29, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', 'FSorY8hXExuanvT', '327/40 HÃ n Háº£i NguyÃªn, P.2, Q.11, Tp.HCM', 0, 'Offline', '2021-11-17 18:36:07'),
(110, 29, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', '8Am4eS29gGpEtud', '327/40 HÃ n Háº£i NguyÃªn, P.2, Q.11, Tp.HCM', 0, 'Offline', '2021-11-17 19:05:28'),
(111, 29, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', 'v17sdkWVbuZ6gaB', '38 Hung Vuong', 0, 'Offline', '2021-11-17 19:06:30'),
(112, 29, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', '2H880849UB052061W', '38 Hung Vuong', 0, 'Paypal(Paid)', '2021-11-18 14:17:11'),
(113, 29, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', '7dvuirSL4Mf8Ut1', '257D Ton Duc Thang,Q.10', 0, 'Offline', '2021-11-18 14:37:31'),
(114, 30, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', 'il0MXmDkuoTWpq2', '327/40 HÃ n Háº£i NguyÃªn, P.2, Q.11, Tp.HCM', 3, 'Offline', '2021-11-18 14:51:42'),
(115, 30, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', '1PM43674G3283661U', '38 Hung Vuong, Ward 1, Kien Tuong Town', 0, 'Paypal(Paid)', '2021-11-20 14:37:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES
(2, 'Farmer Markets'),
(3, '3F'),
(4, 'Fresh food'),
(5, 'Healthy Food');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartId`, `productId`, `sId`, `productName`, `price`, `quantity`, `image`) VALUES
(427, 36, 'e41kpb8552gqt1pgmvo60rr1jn', 'Blackberry', '95000', 1, 'c2bd6a1df9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(11) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(2, 'Fish'),
(3, 'Chicken'),
(6, 'Meat'),
(7, 'Vegetable'),
(8, 'Fruit');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE `tbl_comment` (
  `comment_id` int(11) NOT NULL,
  `user_comment` varchar(255) NOT NULL,
  `comment_detail` text NOT NULL,
  `productId` int(11) NOT NULL,
  `blog_id` int(11) NOT NULL,
  `date_cmt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comment_id`, `user_comment`, `comment_detail`, `productId`, `blog_id`, `date_cmt`) VALUES
(60, 'toan.job@gmail.com', 'This product so tasty !!!!! Thank you.', 9, 0, '2021-09-09 12:22:12'),
(61, 'toan.job@gmail.com', 'Love it very much !', 9, 0, '2021-09-09 12:22:12'),
(67, 'Tuannm@fpt.edu.vn', 'So tasty !!!!', 7, 0, '2021-09-09 12:22:12'),
(68, 'Tuannm@fpt.edu.vn', ':(((', 7, 0, '2021-09-09 12:22:12'),
(69, 'toan.job@gmail.com', 'dsdsdsadas', 9, 0, '2021-09-09 12:22:12'),
(72, 'toan.job@gmail.com', 'Thank', 13, 0, '2021-09-09 12:22:12'),
(73, 'toan.job@gmail.com', 'Hello!', 15, 0, '2021-09-09 12:22:12'),
(74, 'Toan', 'Hello', 23, 0, '2021-09-09 12:22:12'),
(77, 'Nguyá»…n Minh Tuáº¥n ', 'adddd', 23, 0, '2021-09-09 12:22:12'),
(78, 'Nguyá»…n Minh Tuáº¥n ', 'Thank for product!', 23, 0, '2021-09-09 12:22:12'),
(79, 'Nguyá»…n Minh Tuáº¥n ', 'Hi', 23, 0, '2021-09-09 12:22:12'),
(80, 'VÃµ Há»“ng PhÃºc', 'So delicious !', 7, 0, '2021-09-09 12:22:12'),
(81, 'Julia', 'Good', 23, 0, '2021-09-09 12:22:12'),
(85, 'Nguyá»…n Minh Tuáº¥n ', 'Hihihi', 23, 0, '2021-09-09 12:22:12'),
(86, 'abc', 'dsd', 23, 0, '2021-09-09 12:22:12'),
(87, 'Toan', 'abc', 24, 0, '2021-09-09 12:41:52'),
(88, 'Toan', 'dsadsdsad', 26, 0, '2021-09-09 18:16:51'),
(89, 'lan', 'dddddddd', 26, 0, '2021-09-09 18:23:06'),
(90, 'huy', 'dsadsadsa', 26, 0, '2021-09-09 18:23:15'),
(91, 'Toan', 'Thank', 26, 0, '2021-09-09 18:23:30'),
(92, 'Toan', 'bfbfb', 26, 0, '2021-09-09 18:23:42'),
(93, 'Toan', 'Food is a product used to feed humans and animals. Most of the food and drink that people use can be called food, but there are foods or drinks used for medicinal purposes that are not called food. From that, we draw the following definition: \"Food is a solid or liquid product used for eating and drinking for nutritional purposes and (or) tastes in addition to those for medicinal purposes.\" ', 23, 0, '2021-09-11 08:01:32'),
(94, 'Tráº§n Äá»©c ToÃ n', 'hi', 30, 0, '2021-11-14 07:04:44'),
(95, 'Tráº§n Äá»©c ToÃ n', 'Good !', 36, 0, '2021-11-21 09:39:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id_contact` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customerName` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `subject` text NOT NULL,
  `date_send` timestamp NOT NULL DEFAULT current_timestamp(),
  `contact_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id_contact`, `customerId`, `customerName`, `customer_email`, `phone`, `subject`, `date_send`, `contact_status`) VALUES
(4, 5, 'Tráº§n Äá»©c ToÃ n', 'toan.job7@gmail.com', 837943763, 'aaaaaaaaaaaaaaaaaaaaa', '2021-08-21 05:28:38', 2),
(5, 5, 'Tráº§n Äá»©c ToÃ n', 'toan.job7@gmail.com', 837943763, 'bbbbbbbbbbb', '2021-08-21 05:30:41', 2),
(9, 5, 'Tráº§n Äá»©c ToÃ n', 'toan.job7@gmail.com', 837943763, 'aaaaaa', '2021-09-08 11:48:45', 2),
(10, 24, 'Tráº§n Äá»©c ToÃ n', 'toan.job@gmail.com', 837943763, 'Thank you for your fresh food!', '2021-09-16 12:05:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `zipcode` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `block` int(11) NOT NULL,
  `id_address` int(11) NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `address`, `city`, `country`, `zipcode`, `phone`, `email`, `password`, `block`, `id_address`, `code`, `status`) VALUES
(5, 'Tráº§n Äá»©c ToÃ n', '38 Hung Vuong,P.1, TX.Kien Tuong, tinh Long An', 'Ho Chi Minh city', 'la', '700000', '837943763', 'toan.job7@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 0, 'verified'),
(6, 'Nguyá»…n Minh Tuáº¥n ', '57A ÄÃ¬nh TÃ¢n Khai, BÃ¬nh Trá»‹ ÄÃ´ng B, Q.BÃ¬nh TÃ¢n', 'Há»“ ChÃ­ Minh', 'hcm', '700000', '0723841386', 'Tuannm@gmail.com', '7301eea172e89a223798467d4a91e7a9', 0, 0, 0, 'verified'),
(7, 'VÃµ Há»“ng PhÃºc', '155 Nguyá»…n Minh ÄÆ°á»ng', 'TP.TÃ¢n An', 'la', '350000', '012587646', 'phucvo@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 0, 'verified'),
(10, 'Tráº§n Äá»©c ToÃ n', '327/40 Han Hai Nguyen,Q.11', 'Ho Chi Minh city', 'null', '700000', '837943763', 'toan.job2@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 0, 'verified'),
(11, 'VÃµ Thá»‹ Lan', '42 HÃ¹ng VÆ°Æ¡ng, P.1', 'Long An', 'la', '60000', '098826465', 'Lanvo@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 0, 'verified'),
(30, 'Tráº§n Äá»©c ToÃ n', '38 Hung Vuong, Ward 1, Kien Tuong Town', 'Ho Chi Minh city', 'la', '700000', '837943763', 'toan.job@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 390893, 'verified'),
(31, 'Tráº§n Äá»©c ToÃ n', '38 Hung Vuong', 'Ho Chi Minh city', 'vt', '700000', '837943763', 'toan.job8@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 685230, 'notverified');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_favoriteproduct`
--

CREATE TABLE `tbl_favoriteproduct` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_favoriteproduct`
--

INSERT INTO `tbl_favoriteproduct` (`id`, `customerId`, `productId`, `productName`, `price`, `image`) VALUES
(13, 7, 15, 'Salmon', '100000', '7309f12929.jpg'),
(31, 6, 24, 'Grapes', '695000', 'e153a63537.jpg'),
(32, 5, 33, 'Chicken Legs', '30000', '53fb5ae0aa.jpg'),
(33, 30, 33, 'Chicken Legs', '30000', '53fb5ae0aa.jpg'),
(34, 30, 36, 'Blackberry', '95000', 'c2bd6a1df9.jpg'),
(35, 30, 34, 'Peony grapes', '1650000', '1ad0367fc1.jpg'),
(36, 30, 35, 'Durian', '200000', '75b6f21b42.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `bill_id` mediumtext NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `dateOrder` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `bill_id`, `productId`, `productName`, `customerId`, `quantity`, `price`, `image`, `status`, `dateOrder`) VALUES
(214, 'WqC0fvnED5HctPT', 26, 'Apple', 24, 2, '278000', '84195ba293.jpg', 0, '2021-09-16 12:01:51'),
(215, 'WqC0fvnED5HctPT', 24, 'Grapes', 24, 1, '695000', 'e153a63537.jpg', 0, '2021-09-16 12:01:51'),
(216, 'CH19yik7GxVeIOm', 22, 'Spinach', 24, 1, '25000', '4348cc9c75.jpg', 0, '2021-09-16 12:02:37'),
(217, 'CH19yik7GxVeIOm', 19, 'Salmon', 24, 3, '1500000', 'af29044ff1.jpg', 0, '2021-09-16 12:02:37'),
(218, 'RF4dwVOu9f5ngmy', 7, 'Chicken', 24, 1, '24000', '5a7c7b41df.png', 0, '2021-09-16 12:21:04'),
(219, 'DrPZHgmpatqWdMU', 25, 'Dragon Fruit', 24, 1, '19000', '93b3d36fd6.jpg', 0, '2021-09-19 11:55:50'),
(220, 'RxbJK0UZNXuInOM', 23, 'Pork Cutlet', 24, 2, '180000', 'a405c271ab.jpg', 0, '2021-10-02 05:36:57'),
(221, 'RxbJK0UZNXuInOM', 25, 'Dragon Fruit', 24, 3, '57000', '93b3d36fd6.jpg', 0, '2021-10-02 05:36:57'),
(222, 'RxbJK0UZNXuInOM', 24, 'Grapes', 24, 1, '695000', 'e153a63537.jpg', 0, '2021-10-02 05:36:57'),
(223, 'RxbJK0UZNXuInOM', 21, 'Beaf (Type 1)', 24, 1, '180000', 'ae79c07136.png', 0, '2021-10-02 05:36:57'),
(224, 'b1iRkegGpwH8ftN', 35, 'Durian', 24, 1, '200000', '75b6f21b42.jpg', 0, '2021-10-02 06:41:35'),
(225, '20P712023C223641W', 36, 'Blackberry', 5, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-07 16:13:26'),
(226, '20P712023C223641W', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:13:26'),
(227, '20P712023C223641W', 26, 'Apple', 5, 1, '139000', '84195ba293.jpg', 0, '2021-11-07 16:13:26'),
(228, '1Y389007L1143720G', 35, 'Durian', 5, 1, '200000', '75b6f21b42.jpg', 0, '2021-11-07 16:18:01'),
(229, '71313385J6377634W', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:26:57'),
(230, '41F12057NE350715V', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:35:30'),
(231, 'EfHBb2QjLI7UDsK', 35, 'Durian', 5, 1, '200000', '75b6f21b42.jpg', 0, '2021-11-07 16:36:36'),
(232, '7GT954139X749194M', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:39:16'),
(233, '0HW40369P1748462K', 36, 'Blackberry', 5, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-07 16:42:27'),
(234, '0HW40369P1748462K', 35, 'Durian', 5, 1, '200000', '75b6f21b42.jpg', 0, '2021-11-07 16:42:27'),
(235, '8H971873NK8808106', 25, 'Dragon Fruit', 5, 1, '19000', '93b3d36fd6.jpg', 0, '2021-11-07 16:44:41'),
(236, '00U00553NC691603G', 31, 'Chicken swing', 5, 1, '80000', 'a2b0eaf01d.jpg', 0, '2021-11-07 16:46:10'),
(237, '7WT167330C993334A', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:54:00'),
(238, '7WT167330C993334A', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:55:35'),
(239, '1VG43549SA1139353', 33, 'Chicken Legs', 5, 3, '90000', '53fb5ae0aa.jpg', 0, '2021-11-07 16:57:19'),
(240, '4B964656KV639584L', 30, 'Pork ribs', 5, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-07 16:58:57'),
(241, '5NB06288H6904380J', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 17:02:00'),
(242, '4CF20374JW9203946', 36, 'Blackberry', 5, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-07 17:04:52'),
(243, '4PG30582PA100362S', 36, 'Blackberry', 5, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-07 17:10:41'),
(244, '0VW8900719908972M', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-07 17:17:42'),
(245, '24075184XK644370S', 30, 'Pork ribs', 5, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-09 15:36:11'),
(246, '35H44777J3095804V', 30, 'Pork ribs', 5, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-09 15:38:19'),
(247, '4B068338KS273504J', 33, 'Chicken Legs', 5, 4, '120000', '53fb5ae0aa.jpg', 0, '2021-11-09 15:40:21'),
(248, '3YN012112U284392K', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 15:44:25'),
(249, '3YN012112U284392K', 36, 'Blackberry', 5, 4, '380000', 'c2bd6a1df9.jpg', 0, '2021-11-09 15:44:25'),
(250, '07J04037V5031630K', 30, 'Pork ribs', 5, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-09 15:46:49'),
(251, '3AD74104TG264970J', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 15:56:19'),
(252, '6UN78318VR965605H', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 16:01:15'),
(253, '1BN25909R7515891H', 30, 'Pork ribs', 5, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-09 16:06:55'),
(254, '69917063WW5093522', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 16:08:23'),
(255, '08688591L44146200', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 16:17:26'),
(256, '8WG72162T83085626', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 16:21:18'),
(257, 'pmWcLfNxOSqsn75', 33, 'Chicken Legs', 5, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-09 16:21:47'),
(258, 'YJnAXdNflLeZb90', 30, 'Pork ribs', 5, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-14 09:40:04'),
(259, 'GOnUbm9K4ajgMhB', 36, 'Blackberry', 29, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-17 18:34:22'),
(260, 'GOnUbm9K4ajgMhB', 31, 'Chicken swing', 29, 3, '240000', 'a2b0eaf01d.jpg', 0, '2021-11-17 18:34:22'),
(261, 'GOnUbm9K4ajgMhB', 29, 'Mackerel', 29, 2, '240000', '812c5cb99b.jpg', 0, '2021-11-17 18:34:22'),
(262, 'FSorY8hXExuanvT', 35, 'Durian', 29, 2, '400000', '75b6f21b42.jpg', 0, '2021-11-17 18:36:07'),
(263, 'FSorY8hXExuanvT', 31, 'Chicken swing', 29, 2, '160000', 'a2b0eaf01d.jpg', 0, '2021-11-17 18:36:07'),
(264, '8Am4eS29gGpEtud', 36, 'Blackberry', 29, 3, '285000', 'c2bd6a1df9.jpg', 0, '2021-11-17 19:05:28'),
(265, '8Am4eS29gGpEtud', 9, 'Onion', 29, 5, '51500', 'c1b0bea91f.png', 0, '2021-11-17 19:05:28'),
(266, '8Am4eS29gGpEtud', 33, 'Chicken Legs', 29, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-17 19:05:28'),
(267, '8Am4eS29gGpEtud', 30, 'Pork ribs', 29, 1, '165000', 'e29951a4ad.jpg', 0, '2021-11-17 19:05:28'),
(268, '8Am4eS29gGpEtud', 34, 'Peony grapes', 29, 1, '1650000', '1ad0367fc1.jpg', 0, '2021-11-17 19:05:28'),
(269, '8Am4eS29gGpEtud', 32, 'Chicken thighs', 29, 1, '90000', '4f83d59046.jpg', 0, '2021-11-17 19:05:28'),
(270, 'v17sdkWVbuZ6gaB', 33, 'Chicken Legs', 29, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-17 19:06:30'),
(271, '2H880849UB052061W', 36, 'Blackberry', 29, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-18 14:17:11'),
(272, '7dvuirSL4Mf8Ut1', 36, 'Blackberry', 29, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-18 14:37:31'),
(273, '7dvuirSL4Mf8Ut1', 35, 'Durian', 29, 1, '200000', '75b6f21b42.jpg', 0, '2021-11-18 14:37:31'),
(274, 'il0MXmDkuoTWpq2', 33, 'Chicken Legs', 30, 1, '30000', '53fb5ae0aa.jpg', 0, '2021-11-18 14:51:42'),
(275, '1PM43674G3283661U', 36, 'Blackberry', 30, 1, '95000', 'c2bd6a1df9.jpg', 0, '2021-11-20 14:37:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` tinytext NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `type` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `catId`, `brandId`, `product_desc`, `type`, `price`, `image`, `status`) VALUES
(7, 'Chicken', 3, 3, '<p>Chicken 3Fs</p>', 1, '24000', '5a7c7b41df.png', 0),
(8, 'Carrot baby', 7, 4, '<p>This is Carrot baby</p>', 0, '25000', 'fb296f0447.png', 0),
(9, 'Onion', 7, 2, '<p>Onion in Farmer market company</p>', 0, '10300', 'c1b0bea91f.png', 0),
(10, 'Cereals', 7, 5, '<p>Cereals tasty</p>', 0, '60000', 'b5630e52b3.png', 0),
(11, 'Strawberry', 8, 4, '<p>Strawberry Korean</p>', 1, '90000', 'd7d8e437b6.png', 0),
(12, 'Blueberry', 8, 4, '<p>Blueberry USA</p>', 1, '132000', '6c02cfaee6.png', 0),
(18, 'Pork Belly', 6, 2, '<p>Pork Belly USA</p>', 0, '166000', '453da0f5b9.jpg', 0),
(19, 'Salmon', 2, 2, '<p>SAlmon (Type 1)</p>', 0, '500000', 'af29044ff1.jpg', 0),
(20, 'Tuna', 2, 2, '<p>Tuna(Type 1)</p>', 0, '350000', '1b6582d29a.png', 0),
(21, 'Beaf (Type 1)', 6, 2, '<p>Beaf(Type1)</p>', 0, '180000', 'ae79c07136.png', 0),
(22, 'Spinach', 7, 5, '<p>So Fresh !</p>', 1, '25000', '4348cc9c75.jpg', 0),
(23, 'Pork Cutlet', 6, 2, '<p>Pork Cutlet&nbsp; From Viet Nam</p>', 0, '90000', 'a405c271ab.jpg', 0),
(24, 'Grapes', 8, 5, '<p>Grape USA</p>', 0, '695000', 'e153a63537.jpg', 0),
(25, 'Dragon Fruit', 8, 4, '<p>Dragon Fruit , so sweet !!</p>', 0, '19000', '93b3d36fd6.jpg', 0),
(26, 'Apple', 8, 4, '<p>Apple Chile</p>', 1, '139000', '84195ba293.jpg', 0),
(28, 'Herring', 2, 4, '<p>So Fresh !</p>', 0, '150000', '4548b3abf2.jpg', 0),
(29, 'Mackerel', 2, 4, '<p>Made in Japan</p>', 1, '120000', '812c5cb99b.jpg', 0),
(30, 'Pork ribs', 6, 2, '<p>So fresh !</p>', 1, '165000', 'e29951a4ad.jpg', 0),
(31, 'Chicken swing', 3, 3, '<p>chicken wings firm, big</p>', 0, '80000', 'a2b0eaf01d.jpg', 0),
(32, 'Chicken thighs', 3, 3, '<p>Chicken thighs firm, big!</p>', 1, '90000', '4f83d59046.jpg', 0),
(33, 'Chicken Legs', 3, 3, '<p>So fresh!</p>', 1, '30000', '53fb5ae0aa.jpg', 0),
(34, 'Peony grapes', 8, 4, '<p>So sweet!</p>', 0, '1650000', '1ad0367fc1.jpg', 0),
(35, 'Durian', 8, 4, '<p>So sweet!</p>', 0, '200000', '75b6f21b42.jpg', 0),
(36, 'Blackberry', 8, 5, '<p>Made in USA</p>', 0, '95000', 'c2bd6a1df9.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `sliderName` varchar(255) NOT NULL,
  `slider_image` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `link_slider` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `sliderName`, `slider_image`, `type`, `link_slider`) VALUES
(14, 'Slider 1', '5f65a8ccd7.jpg', 1, 'detail-products/24.html'),
(15, 'Slider 2', '6b1b0dab26.jpg', 1, 'detail-products/25.html'),
(16, 'Slider 3', '5dd3186ae4.jpg', 1, 'detail-products/26.html');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_bill`
--
ALTER TABLE `tbl_bill`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id_contact`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_favoriteproduct`
--
ALTER TABLE `tbl_favoriteproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_bill`
--
ALTER TABLE `tbl_bill`
  MODIFY `bill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=428;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id_contact` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_favoriteproduct`
--
ALTER TABLE `tbl_favoriteproduct`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=276;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
